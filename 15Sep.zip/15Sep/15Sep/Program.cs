﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace _15Sep
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Contains.Execute();
            //pricelessthan1000.price();
            // Lowestprice.Lowprice();
            //MaxBetTwo.Execute();
            //HeighestBetAll.Execute();
            //InBetweenPrice.Execution();
            //SquareRoot.Execution();
        }
    }
}
